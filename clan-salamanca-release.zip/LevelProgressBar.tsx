import { motion } from "framer-motion";
import clsx from "clsx";

export function LevelProgressBar(props: {
  level: number;
  xpIntoLevel: number;
  xpForNext: number;
  showLabel?: boolean;
  className?: string;
}) {
  const pct = Math.min(1, props.xpForNext ? props.xpIntoLevel / props.xpForNext : 0);
  const tier = props.level >= 50 ? "legendary" : props.level >= 25 ? "epic" : props.level >= 10 ? "rare" : "common";
  const bar = tier === "legendary" ? "bg-yellow-300" : tier === "epic" ? "bg-purple-400" : tier === "rare" ? "bg-steam-accent" : "bg-steam-green";
  const glowClass = tier === "legendary" ? "rarity-glow--legendary" : tier === "epic" ? "rarity-glow--epic" : tier === "rare" ? "rarity-glow--rare" : "rarity-glow--common";

  return (
    <div className={clsx("grid gap-2", props.className)}>
      {props.showLabel ? (
        <div className="flex items-center justify-between text-xs">
          <span className="text-steam-muted">Level</span>
          <span className={clsx("font-semibold", tier === "legendary" && "text-yellow-300")}>{props.level}</span>
        </div>
      ) : null}
      <div className="h-2 overflow-hidden rounded-full bg-white/10">
        <motion.div
          className={clsx("h-full rounded-full rarity-glow", bar, glowClass)}
          initial={{ width: 0 }}
          animate={{ width: `${Math.round(pct * 100)}%` }}
          transition={{ duration: 0.9, ease: "easeInOut" }}
        />
      </div>
      {props.showLabel ? (
        <div className="text-[11px] text-steam-muted">
          XP {props.xpIntoLevel} / {props.xpForNext}
        </div>
      ) : null}
    </div>
  );
}

