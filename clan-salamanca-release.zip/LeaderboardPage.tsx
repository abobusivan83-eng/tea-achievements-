import { useEffect, useState } from "react";
import { apiFetch } from "../lib/api";
import type { LeaderboardRow } from "../lib/types";
import { Modal } from "../ui/components/Modal";
import { Button } from "../ui/components/Button";
import { FiAward, FiX } from "react-icons/fi";
import { RatingList } from "../ui/components/RatingList";
import { Reveal } from "../ui/components/Reveal";
import { Skeleton } from "../ui/components/Skeleton";
import { AvatarFrame } from "../ui/components/AvatarFrame";

export function LeaderboardPage() {
  const [rows, setRows] = useState<LeaderboardRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<LeaderboardRow | null>(null);

  useEffect(() => {
    let mounted = true;
    async function run() {
      setLoading(true);
      setError(null);
      try {
        const data = await apiFetch<LeaderboardRow[]>("/api/leaderboard");
        if (!mounted) return;
        setRows(data);
      } catch (e: any) {
        setError(e?.message ?? "Ошибка загрузки рейтинга");
      } finally {
        setLoading(false);
      }
    }
    run();
    const id = setInterval(run, 8000); // dynamic-ish refresh
    return () => {
      mounted = false;
      clearInterval(id);
    };
  }, []);

  return (
    <div className="grid gap-5">
      <Reveal className="steam-card steam-card--hover p-4">
        <div className="text-lg font-semibold">Рейтинг клана</div>
        <div className="text-sm text-steam-muted">Топ участников по сумме очков достижений. Обновляется автоматически.</div>
      </Reveal>

      {loading ? (
        <div className="steam-card overflow-hidden">
          <div className="grid grid-cols-[56px_1fr_130px_120px] gap-2 border-b border-white/10 bg-black/20 px-4 py-3 text-xs text-steam-muted">
            <div>#</div>
            <div>Player</div>
            <div>Level</div>
            <div>Points</div>
          </div>
          {Array.from({ length: 10 }).map((_, i) => (
            <div
              key={i}
              className={`grid w-full grid-cols-[56px_1fr_130px_120px] items-center gap-2 px-4 py-3 ${i % 2 === 0 ? "bg-white/0" : "bg-white/5"}`}
            >
              <Skeleton className="h-4 w-10 rounded-md" />
              <div className="grid gap-2">
                <Skeleton className="h-4 w-40 rounded-md" />
                <Skeleton className="h-3 w-56 rounded-md" />
              </div>
              <Skeleton className="h-6 w-12 rounded-md" />
              <Skeleton className="h-4 w-20 rounded-md" />
            </div>
          ))}
        </div>
      ) : null}
      {error ? <div className="steam-card p-4">{error}</div> : null}

      <RatingList rows={rows} onSelect={setSelected} />

      <Modal
        open={Boolean(selected)}
        title={selected ? `Player: ${selected.nickname}` : undefined}
        onClose={() => setSelected(null)}
      >
        {selected ? (
          <div className="grid gap-3">
            <div className="flex items-center gap-3">
              <AvatarFrame
                frameKey={selected.frameKey}
                size={48}
                src={selected.avatarUrl ?? "https://placehold.co/96x96/png?text=U"}
              />
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold">{selected.nickname}</div>
                <div className="truncate font-mono text-[11px] text-steam-muted">{selected.id}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl border border-white/10 bg-black/20 p-3">
                <div className="text-xs text-steam-muted">Achievements</div>
                <div className="mt-1 text-lg font-semibold">{selected.achievementCount}</div>
              </div>
              <div className="rounded-xl border border-white/10 bg-black/20 p-3">
                <div className="text-xs text-steam-muted">Points</div>
                <div className="mt-1 text-lg font-semibold text-steam-accent">{selected.totalPoints}</div>
              </div>
            </div>

            <div className="rounded-xl border border-white/10 bg-black/20 p-3 text-sm text-steam-muted">
              <div className="inline-flex items-center gap-2 text-steam-text">
                <FiAward />
                <span className="font-semibold">Interactive hint</span>
              </div>
              <div className="mt-2">
                Later we can show this player’s achievements preview here (requires a small API endpoint).
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="ghost" leftIcon={<FiX />} onClick={() => setSelected(null)}>
                Close
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}



