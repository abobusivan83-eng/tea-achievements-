import { API_BASE_URL } from "./config";
import { useLoading } from "../state/loading";

type ApiOk<T> = { ok: true; data: T };
type ApiErr = { ok: false; error: { message: string } };
type ApiResp<T> = ApiOk<T> | ApiErr;

export class ApiError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
  }
}

function getToken() {
  return localStorage.getItem("token");
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const token = getToken();
  useLoading.getState().start();
  try {
    const res = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      headers: {
        ...(init?.headers ?? {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });

    const json = (await res.json().catch(() => null)) as ApiResp<T> | null;
    if (!res.ok) throw new ApiError(json && "ok" in json && !json.ok ? json.error.message : "Request failed", res.status);
    if (!json || !("ok" in json) || !json.ok) throw new ApiError((json as any)?.error?.message ?? "Request failed");
    return (json as ApiOk<T>).data;
  } finally {
    useLoading.getState().end();
  }
}

export async function apiDelete<T>(path: string) {
  return apiFetch<T>(path, { method: "DELETE" });
}

export async function apiJson<T>(path: string, body: unknown, method: string = "POST") {
  return apiFetch<T>(path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function apiUpload<T>(path: string, file: File) {
  const form = new FormData();
  form.append("file", file);
  return apiFetch<T>(path, { method: "POST", body: form });
}

