import { Router } from "express";
import { z } from "zod";
import path from "path";
import fs from "fs";
import { prisma } from "../lib/prisma.js";
import { fail, ok } from "../lib/http.js";
import { requireAuth, requireAdmin, type AuthedRequest } from "../middleware/auth.js";
import { upload } from "../middleware/uploads.js";
import { env } from "../lib/env.js";
import { toPublicFileUrl } from "../lib/publicUrl.js";
import { levelFromXp } from "../lib/levels.js";

export const adminRouter = Router();

adminRouter.use(requireAuth, requireAdmin);

function ensureDir(p: string) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function toRelUploadPath(absPath: string) {
  const rel = path.relative(process.cwd(), absPath);
  return rel.replaceAll("\\", "/");
}

const CreateAchievementSchema = z.object({
  title: z.string().min(2).max(64),
  description: z.string().min(2).max(256),
  rarity: z.enum(["COMMON", "RARE", "EPIC", "LEGENDARY"]),
  points: z.coerce.number().int().min(1).max(10000).optional(),
  frameKey: z.string().min(1).max(64).nullable().optional(),
  isPublic: z.coerce.boolean().default(true),
  // For private achievements visibility list (can be empty even if isPublic=true).
  grantUserIds: z.array(z.string().uuid()).optional(),
});

adminRouter.get("/achievements", async (_req, res) => {
  const items = await prisma.achievement.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      title: true,
      description: true,
      rarity: true,
      points: true,
      iconPath: true,
      frameKey: true,
      isPublic: true,
      createdAt: true,
      updatedAt: true,
    },
    take: 500,
  });

  return ok(
    res,
    items.map((a) => ({
      ...a,
      iconUrl: toPublicFileUrl(a.iconPath),
    })),
  );
});

adminRouter.post("/achievements", async (req: AuthedRequest, res) => {
  const parsed = CreateAchievementSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, parsed.error.issues[0]?.message ?? "Invalid payload");

  const defaultPointsByRarity: Record<string, number> = {
    COMMON: 10,
    RARE: 30,
    EPIC: 70,
    LEGENDARY: 150,
  };

  const a = await prisma.achievement.create({
    data: {
      title: parsed.data.title,
      description: parsed.data.description,
      rarity: parsed.data.rarity,
      points: parsed.data.points ?? defaultPointsByRarity[parsed.data.rarity],
      frameKey: parsed.data.frameKey ?? null,
      isPublic: parsed.data.isPublic,
      createdById: req.user!.id,
      accessGrants: parsed.data.grantUserIds?.length
        ? {
            create: parsed.data.grantUserIds.map((userId) => ({ userId })),
          }
        : undefined,
    },
    select: { id: true, title: true, rarity: true, points: true, isPublic: true },
  });

  return ok(res, a);
});

const UpdateAchievementSchema = z.object({
  title: z.string().min(2).max(64).optional(),
  description: z.string().min(2).max(256).optional(),
  rarity: z.enum(["COMMON", "RARE", "EPIC", "LEGENDARY"]).optional(),
  points: z.coerce.number().int().min(1).max(10000).optional(),
  frameKey: z.string().min(1).max(64).nullable().optional(),
  isPublic: z.coerce.boolean().optional(),
});

adminRouter.patch("/achievements/:id", async (req, res) => {
  const parsed = UpdateAchievementSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Invalid payload");

  const updated = await prisma.achievement.update({
    where: { id: req.params.id },
    data: {
      title: parsed.data.title,
      description: parsed.data.description,
      rarity: parsed.data.rarity,
      points: parsed.data.points,
      frameKey: parsed.data.frameKey ?? undefined,
      isPublic: typeof parsed.data.isPublic === "boolean" ? parsed.data.isPublic : undefined,
    },
    select: {
      id: true,
      title: true,
      description: true,
      rarity: true,
      points: true,
      iconPath: true,
      frameKey: true,
      isPublic: true,
      updatedAt: true,
    },
  });

  return ok(res, { ...updated, iconUrl: toPublicFileUrl(updated.iconPath) });
});

adminRouter.delete("/achievements/:id", async (req, res) => {
  const achievementId = req.params.id;
  const exists = await prisma.achievement.findUnique({ where: { id: achievementId } });
  if (!exists) return fail(res, 404, "Achievement not found");

  await prisma.achievement.delete({ where: { id: achievementId } });
  return ok(res, { deleted: true });
});

// Upload achievement icon (image)
adminRouter.post("/achievements/:id/icon", upload.single("file"), async (req, res) => {
  const achievementId = req.params.id;
  const file = (req as any).file as Express.Multer.File | undefined;
  if (!file) return fail(res, 400, "No file");

  // Move file into achievements folder for tidier storage
  const destDir = path.resolve(process.cwd(), env.UPLOAD_DIR, "achievements");
  ensureDir(destDir);

  const destPath = path.join(destDir, path.basename(file.path));
  fs.renameSync(file.path, destPath);

  const relPath = toRelUploadPath(destPath);
  const updated = await prisma.achievement.update({
    where: { id: achievementId },
    data: { iconPath: relPath },
    select: { id: true, iconPath: true },
  });

  return ok(res, { iconUrl: toPublicFileUrl(updated.iconPath) });
});

const AwardSchema = z.object({
  userId: z.string().uuid(),
});

adminRouter.post("/achievements/:id/award", async (req, res) => {
  const achievementId = req.params.id;
  const parsed = AwardSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Invalid payload");

  // Ensure access exists for private achievements.
  const ach = await prisma.achievement.findUnique({ where: { id: achievementId } });
  if (!ach) return fail(res, 404, "Achievement not found");

  if (!ach.isPublic) {
    await prisma.achievementAccess.upsert({
      where: { achievementId_userId: { achievementId, userId: parsed.data.userId } },
      create: { achievementId, userId: parsed.data.userId },
      update: {},
    });
  }

  // Award + XP in one transaction (idempotent award).
  const already = await prisma.userAchievement.findUnique({
    where: { userId_achievementId: { userId: parsed.data.userId, achievementId } },
  });

  await prisma.$transaction(async (tx) => {
    if (!already) {
      await tx.userAchievement.create({ data: { userId: parsed.data.userId, achievementId } });
      await tx.user.update({
        where: { id: parsed.data.userId },
        data: { xp: { increment: ach.points } },
      });
    }
  });

  return ok(res, { awarded: true });
});

adminRouter.post("/achievements/:id/revoke", async (req, res) => {
  const achievementId = req.params.id;
  const parsed = AwardSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Invalid payload");

  const ach = await prisma.achievement.findUnique({ where: { id: achievementId } });
  if (!ach) return fail(res, 404, "Achievement not found");

  const existed = await prisma.userAchievement.findUnique({
    where: { userId_achievementId: { userId: parsed.data.userId, achievementId } },
  });

  await prisma.$transaction(async (tx) => {
    if (existed) {
      await tx.userAchievement.delete({ where: { userId_achievementId: { userId: parsed.data.userId, achievementId } } });
      await tx.user.update({
        where: { id: parsed.data.userId },
        data: { xp: { decrement: ach.points } },
      });
    }
  });

  return ok(res, { revoked: true });
});

const GrantAccessSchema = z.object({
  userIds: z.array(z.string().uuid()).min(1).max(200),
});

adminRouter.post("/achievements/:id/grant", async (req, res) => {
  const achievementId = req.params.id;
  const parsed = GrantAccessSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Invalid payload");

  await prisma.achievementAccess.createMany({
    data: parsed.data.userIds.map((userId) => ({ achievementId, userId })),
  });

  return ok(res, { granted: true });
});

adminRouter.get("/users", async (_req, res) => {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      nickname: true,
      email: true,
      role: true,
      blocked: true,
      level: true,
      xp: true,
      adminNotes: true,
      adminTags: true,
      createdAt: true,
    },
    take: 200,
  });
  return ok(
    res,
    users.map((u) => ({
      ...u,
      adminTags: (u.adminTags as unknown as string[] | null) ?? [],
      xpIntoLevel: levelFromXp(u.xp).xpIntoLevel,
      xpForNext: levelFromXp(u.xp).xpForNext,
    })),
  );
});

const UpdateUserSchema = z.object({
  role: z.enum(["USER", "ADMIN"]).optional(),
  blocked: z.boolean().optional(),
  nickname: z.string().min(2).max(24).optional(),
  adminNotes: z.string().max(2000).nullable().optional(),
  adminTags: z.array(z.string().min(1).max(32)).max(32).optional(),
  level: z.coerce.number().int().min(1).max(500).optional(),
  xp: z.coerce.number().int().min(0).max(2_000_000_000).optional(),
});

adminRouter.patch("/users/:id", async (req, res) => {
  const parsed = UpdateUserSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Invalid payload");

  const updated = await prisma.user.update({
    where: { id: req.params.id },
    data: {
      role: parsed.data.role,
      blocked: parsed.data.blocked,
      nickname: parsed.data.nickname,
      adminNotes: parsed.data.adminNotes ?? undefined,
      adminTags: parsed.data.adminTags ? parsed.data.adminTags : undefined,
      level: parsed.data.level,
      xp: parsed.data.xp,
    },
    select: { id: true, nickname: true, email: true, role: true, blocked: true, adminNotes: true, adminTags: true },
  });

  return ok(res, { ...updated, adminTags: (updated.adminTags as unknown as string[] | null) ?? [] });
});

