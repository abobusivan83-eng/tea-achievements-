import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../state/auth";

export function RegisterPage() {
  const nav = useNavigate();
  const register = useAuth((s) => s.register);
  const [nickname, setNickname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <div className="mx-auto flex min-h-screen max-w-md items-center px-4">
      <div className="steam-card w-full p-6">
        <h1 className="text-xl font-semibold">Регистрация</h1>
        <p className="mt-1 text-sm text-steam-muted">Никнейм + почта + пароль. После регистрации выдаётся уникальный ID.</p>

        <form
          className="mt-5 grid gap-3"
          onSubmit={async (e) => {
            e.preventDefault();
            setError(null);
            setLoading(true);
            try {
              await register(nickname, email, password);
              nav("/profile");
            } catch (e: any) {
              setError(e?.message ?? "Ошибка регистрации");
            } finally {
              setLoading(false);
            }
          }}
        >
          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">Никнейм</span>
            <input
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="Например, Salamanca"
            />
          </label>

          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">Почта</span>
            <input
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>

          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">Пароль</span>
            <input
              type="password"
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>

          {error ? <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm">{error}</div> : null}

          <button
            disabled={loading}
            className="mt-2 rounded-lg bg-steam-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-60"
          >
            {loading ? "Создаём…" : "Создать аккаунт"}
          </button>
        </form>

        <div className="mt-4 text-sm text-steam-muted">
          Уже есть аккаунт?{" "}
          <Link className="text-steam-accent hover:underline" to="/login">
            Войти
          </Link>
        </div>
      </div>
    </div>
  );
}

