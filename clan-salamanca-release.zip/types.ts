export type Role = "USER" | "ADMIN";
export type Rarity = "COMMON" | "RARE" | "EPIC" | "LEGENDARY";

export type Me = {
  id: string;
  nickname: string;
  email: string;
  role: Role;
  blocked: boolean;
  level?: number;
  xp?: number;
  avatarPath?: string | null;
  bannerPath?: string | null;
  frameKey?: string | null;
  badgesJson?: unknown;
  statusEmoji?: string | null;
  createdAt: string;
};

export type Achievement = {
  id: string;
  title: string;
  description: string;
  rarity: Rarity;
  points: number;
  iconUrl: string | null;
  frameKey: string | null;
  isPublic: boolean;
  createdAt: string;
  earned: boolean;
  awardedAt: string | null;
};

export type LeaderboardRow = {
  id: string;
  nickname: string;
  avatarUrl: string | null;
  frameKey: string | null;
  totalPoints: number;
  achievementCount: number;
  level?: number;
  xp?: number;
  xpIntoLevel?: number;
  xpForNext?: number;
};

export type AdminUserRow = {
  id: string;
  nickname: string;
  email: string;
  role: Role;
  blocked: boolean;
  level?: number;
  xp?: number;
  xpIntoLevel?: number;
  xpForNext?: number;
  adminNotes?: string | null;
  adminTags?: string[];
  createdAt: string;
};

export type AdminAchievement = {
  id: string;
  title: string;
  description: string;
  rarity: Rarity;
  points: number;
  iconUrl: string | null;
  frameKey: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
};

