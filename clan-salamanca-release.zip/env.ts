import { z } from "zod";

const EnvSchema = z.object({
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(16),
  PORT: z.coerce.number().int().positive().default(4000),
  PUBLIC_BASE_URL: z.string().url().default("http://localhost:4000"),
  UPLOAD_DIR: z.string().min(1).default("uploads"),
});

export const env = EnvSchema.parse(process.env);

