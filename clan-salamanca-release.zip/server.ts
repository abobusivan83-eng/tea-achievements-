import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import { env } from "./lib/env.js";
import { authRouter } from "./routes/auth.js";
import { usersRouter } from "./routes/users.js";
import { achievementsRouter } from "./routes/achievements.js";
import { leaderboardRouter } from "./routes/leaderboard.js";
import { adminRouter } from "./routes/admin.js";
import { fail, ok } from "./lib/http.js";

const app = express();

app.use(
  cors({
    origin: true,
    credentials: true,
  }),
);
app.use(express.json({ limit: "1mb" }));

// Serve uploaded images (avatar/banner/achievement icons)
app.use(`/${env.UPLOAD_DIR}`, express.static(path.resolve(process.cwd(), env.UPLOAD_DIR)));

app.get("/api/health", (_req, res) => ok(res, { status: "ok" }));
app.use("/api/auth", authRouter);
app.use("/api/users", usersRouter);
app.use("/api/achievements", achievementsRouter);
app.use("/api/leaderboard", leaderboardRouter);
app.use("/api/admin", adminRouter);

// Basic error handler (multer errors, etc.)
app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const msg = err instanceof Error ? err.message : "Unknown error";
  return fail(res, 500, msg);
});

app.listen(env.PORT, () => {
  console.log(`API listening on ${env.PUBLIC_BASE_URL}`);
});

