import { Router } from "express";
import { z } from "zod";
import path from "path";
import { prisma } from "../lib/prisma.js";
import { fail, ok } from "../lib/http.js";
import { requireAuth, type AuthedRequest } from "../middleware/auth.js";
import { upload } from "../middleware/uploads.js";
import { env } from "../lib/env.js";
import { toPublicFileUrl } from "../lib/publicUrl.js";

export const usersRouter = Router();

function toRelUploadPath(absPath: string) {
  const uploadRoot = path.resolve(process.cwd(), env.UPLOAD_DIR);
  const rel = path.relative(process.cwd(), absPath);
  // Ensure it always starts with uploads/
  if (rel.startsWith(env.UPLOAD_DIR)) return rel.replaceAll("\\", "/");
  return path.relative(process.cwd(), path.join(uploadRoot, path.basename(absPath))).replaceAll("\\", "/");
}

const UpdateProfileSchema = z.object({
  nickname: z.string().min(2).max(24).optional(),
  frameKey: z.string().min(1).max(64).nullable().optional(),
  badges: z.array(z.string().min(1).max(64)).max(24).optional(),
  statusEmoji: z.string().min(1).max(8).nullable().optional(),
});

// Self profile editable settings (frame/badges/nickname)
usersRouter.patch("/me", requireAuth, async (req: AuthedRequest, res) => {
  const parsed = UpdateProfileSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, "Invalid payload");

  const user = await prisma.user.update({
    where: { id: req.user!.id },
    data: {
      nickname: parsed.data.nickname,
      frameKey: parsed.data.frameKey ?? undefined,
      badgesJson: parsed.data.badges ? parsed.data.badges : undefined,
      statusEmoji: parsed.data.statusEmoji ?? undefined,
    },
    select: { id: true, nickname: true, frameKey: true, badgesJson: true, statusEmoji: true },
  });
  return ok(res, user);
});

// Upload avatar
usersRouter.post(
  "/me/avatar",
  requireAuth,
  upload.single("file"),
  async (req: AuthedRequest, res) => {
    const file = (req as any).file as Express.Multer.File | undefined;
    if (!file) return fail(res, 400, "No file");

    const relPath = toRelUploadPath(file.path);
    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: { avatarPath: relPath },
      select: { id: true, avatarPath: true },
    });
    return ok(res, { avatarUrl: toPublicFileUrl(user.avatarPath) });
  },
);

// Upload banner
usersRouter.post(
  "/me/banner",
  requireAuth,
  upload.single("file"),
  async (req: AuthedRequest, res) => {
    const file = (req as any).file as Express.Multer.File | undefined;
    if (!file) return fail(res, 400, "No file");

    const relPath = toRelUploadPath(file.path);
    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: { bannerPath: relPath },
      select: { id: true, bannerPath: true },
    });
    return ok(res, { bannerUrl: toPublicFileUrl(user.bannerPath) });
  },
);

// Public profile (Steam-like card with achievements)
usersRouter.get("/:id", requireAuth, async (req: AuthedRequest, res) => {
  const targetId = req.params.id;
  const viewerId = req.user!.id;

  // Determine which achievements are visible to the viewer for this target user.
  // Public achievements are visible to everyone. Private achievements are visible only if access exists for that target user.
  const visibleAchievements = await prisma.achievement.findMany({
    where: {
      OR: [
        { isPublic: true },
        { isPublic: false, accessGrants: { some: { userId: targetId } } },
      ],
    },
    select: {
      id: true,
      title: true,
      description: true,
      rarity: true,
      points: true,
      iconPath: true,
      frameKey: true,
      isPublic: true,
      createdAt: true,
      awards: { where: { userId: targetId }, select: { awardedAt: true } },
    },
    orderBy: [{ rarity: "asc" }, { createdAt: "desc" }],
  });

  const target = await prisma.user.findUnique({
    where: { id: targetId },
    select: {
      id: true,
      nickname: true,
      role: true,
      blocked: true,
      level: true,
      xp: true,
      avatarPath: true,
      bannerPath: true,
      frameKey: true,
      badgesJson: true,
      statusEmoji: true,
      createdAt: true,
    },
  });
  if (!target) return fail(res, 404, "User not found");
  if (target.blocked && viewerId !== targetId && req.user!.role !== "ADMIN") return fail(res, 403, "User blocked");

  const earned = visibleAchievements
    .filter((a) => a.awards.length > 0)
    .map((a) => ({
      ...a,
      iconUrl: toPublicFileUrl(a.iconPath),
      awardedAt: a.awards[0]!.awardedAt,
    }));

  const locked = visibleAchievements
    .filter((a) => a.awards.length === 0)
    .map((a) => ({ ...a, iconUrl: toPublicFileUrl(a.iconPath) }));

  return ok(res, {
    user: {
      ...target,
      avatarUrl: toPublicFileUrl(target.avatarPath),
      bannerUrl: toPublicFileUrl(target.bannerPath),
      badges: (target.badgesJson as unknown as string[] | null) ?? [],
    },
    achievements: { earned, locked },
  });
});

