import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../state/auth";

export function LoginPage() {
  const nav = useNavigate();
  const login = useAuth((s) => s.login);
  const [email, setEmail] = useState("admin@clan.local");
  const [password, setPassword] = useState("admin12345");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <div className="mx-auto flex min-h-screen max-w-md items-center px-4">
      <div className="steam-card w-full p-6">
        <h1 className="text-xl font-semibold">Вход</h1>
        <p className="mt-1 text-sm text-steam-muted">Steam‑стилистика, расширенный профиль, достижения и рейтинг.</p>

        <form
          className="mt-5 grid gap-3"
          onSubmit={async (e) => {
            e.preventDefault();
            setError(null);
            setLoading(true);
            try {
              await login(email, password);
              nav("/profile");
            } catch (e: any) {
              setError(e?.message ?? "Ошибка входа");
            } finally {
              setLoading(false);
            }
          }}
        >
          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">Почта</span>
            <input
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>

          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">Пароль</span>
            <input
              type="password"
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>

          {error ? <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm">{error}</div> : null}

          <button
            disabled={loading}
            className="mt-2 rounded-lg bg-steam-accent px-4 py-2 text-sm font-semibold text-black hover:brightness-110 disabled:opacity-60"
          >
            {loading ? "Входим…" : "Войти"}
          </button>
        </form>

        <div className="mt-4 text-sm text-steam-muted">
          Нет аккаунта?{" "}
          <Link className="text-steam-accent hover:underline" to="/register">
            Регистрация
          </Link>
        </div>
      </div>
    </div>
  );
}

