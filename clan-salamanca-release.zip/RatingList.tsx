import { motion } from "framer-motion";
import clsx from "clsx";
import type { LeaderboardRow } from "../../lib/types";
import { Tooltip } from "./Tooltip";
import { LevelProgressBar } from "./LevelProgressBar";

export function RatingList(props: { rows: LeaderboardRow[]; onSelect: (r: LeaderboardRow) => void }) {
  return (
    <div className="steam-card overflow-hidden">
      <div className="grid grid-cols-[56px_1fr_130px_120px] gap-2 border-b border-white/10 bg-black/20 px-4 py-3 text-xs text-steam-muted">
        <div>#</div>
        <div>Player</div>
        <div>Level</div>
        <div>Points</div>
      </div>
      {props.rows.map((r, idx) => {
        const topGlow =
          idx === 0
            ? "shadow-xl shadow-yellow-400/25"
            : idx === 1
              ? "shadow-lg shadow-slate-200/15"
              : idx === 2
                ? "shadow-lg shadow-amber-700/20"
                : "";
        const lvl = r.level ?? 1;
        const xpInto = r.xpIntoLevel ?? 0;
        const xpForNext = r.xpForNext ?? 1;
        return (
          <Tooltip
            key={r.id}
            content={
              <div className="grid gap-2">
                <div className="text-xs">
                  <span className="text-steam-muted">Achievements:</span> {r.achievementCount}
                </div>
                <div className="text-xs">
                  <span className="text-steam-muted">Level:</span> {lvl}
                </div>
                <div className="w-56">
                  <LevelProgressBar level={lvl} xpIntoLevel={xpInto} xpForNext={xpForNext} />
                </div>
              </div>
            }
          >
            <motion.button
              type="button"
              whileHover={{ y: -1, scale: 1.006 }}
              whileTap={{ scale: 0.992 }}
              transition={{ type: "spring", stiffness: 520, damping: 34 }}
              className={clsx(
                "grid w-full grid-cols-[56px_1fr_130px_120px] items-center gap-2 px-4 py-3 text-left",
                idx % 2 === 0 ? "bg-white/0" : "bg-white/5",
                "hover:bg-white/10",
                topGlow,
              )}
              onClick={() => props.onSelect(r)}
            >
              <div className="text-sm text-steam-muted">{idx + 1}</div>
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold">{r.nickname}</div>
                <div className="truncate font-mono text-[11px] text-steam-muted">{r.id}</div>
              </div>
              <div className="text-sm">
                <span className={clsx("rounded-md border border-white/10 bg-white/5 px-2 py-1", idx < 3 && "text-steam-text")}>
                  {lvl}
                </span>
              </div>
              <div className="text-sm font-semibold text-steam-accent">{r.totalPoints}</div>
            </motion.button>
          </Tooltip>
        );
      })}
    </div>
  );
}

