import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import clsx from "clsx";
import type { Achievement } from "../../lib/types";
import { rarityGlowClass } from "../../ui/rarityStyles";

export function AchievementCard(props: { a: Achievement; isNew?: boolean; onSeenNew?: () => void }) {
  const glow = rarityGlowClass(props.a.rarity, props.a.earned);
  const reduce = useReducedMotion();
  return (
    <motion.div
      layout
      initial={reduce ? { opacity: 0 } : { opacity: 0, y: 10 }}
      animate={reduce ? { opacity: 1 } : { opacity: 1, y: 0 }}
      whileHover={reduce ? undefined : { y: -2, scale: 1.008 }}
      transition={{ type: "spring", stiffness: 520, damping: 34 }}
      className={clsx(
        "steam-card steam-card--hover relative overflow-hidden p-4",
        !props.a.earned && "opacity-75",
        glow,
      )}
    >
      <div className="flex items-start gap-3">
        <div className="h-12 w-12 overflow-hidden rounded-xl border border-white/10 bg-black/30">
          {props.a.iconUrl ? (
            <img className="h-full w-full object-cover" src={props.a.iconUrl} alt="" loading="lazy" decoding="async" />
          ) : null}
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold">{props.a.title}</div>
          <div className="mt-0.5 text-xs text-steam-muted">{props.a.description}</div>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1">{props.a.rarity}</span>
            <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1">{props.a.points} pts</span>
            <span
              className={clsx(
                "rounded-md px-2 py-1 transition-all duration-300 ease-in-out",
                props.a.earned ? "bg-steam-green/15 text-steam-green" : "bg-white/5 text-steam-muted",
              )}
            >
              {props.a.earned ? "Unlocked" : "Locked"}
            </span>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {props.isNew && props.a.earned ? (
          <motion.div
            className="pointer-events-none absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onAnimationComplete={() => props.onSeenNew?.()}
          >
            <motion.div
              className="absolute inset-y-0 left-0 w-[55%]"
              initial={reduce ? { opacity: 0 } : { x: "-120%", opacity: 0 }}
              animate={reduce ? { opacity: 0.9 } : { x: "220%", opacity: 0.95 }}
              transition={reduce ? { duration: 0.18 } : { duration: 0.85, ease: [0.2, 0.8, 0.2, 1] }}
              style={{
                background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.16), transparent)",
                transform: "skewX(-18deg)",
              }}
            />
          </motion.div>
        ) : null}
      </AnimatePresence>
    </motion.div>
  );
}

