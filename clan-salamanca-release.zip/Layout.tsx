import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../state/auth";
import clsx from "clsx";
import type { ReactNode } from "react";
import { Button } from "./components/Button";
import { FiAward, FiHome, FiShield, FiTrendingUp, FiUser } from "react-icons/fi";
import { Toasts } from "./Toasts";
import { LoadingOverlay } from "./components/LoadingOverlay";
import { Scene, type SceneId } from "./components/Scene";
import { motion } from "framer-motion";

export function Layout(props: { children: ReactNode }) {
  const { me, logout, isAdmin } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const scene: SceneId =
    loc.pathname.startsWith("/profile")
      ? "profile"
      : loc.pathname.startsWith("/achievements")
        ? "achievements"
        : loc.pathname.startsWith("/leaderboard")
          ? "leaderboard"
          : loc.pathname.startsWith("/admin")
            ? "admin"
            : "default";

  return (
    <Scene id={scene}>
      <Toasts />
      <LoadingOverlay />
      <header className="sticky top-0 z-10 border-b border-white/10 bg-black/35 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2 text-lg font-semibold tracking-wide text-steam-accent">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 shadow-steam">
              <FiHome />
            </span>
            <span>Achievements</span>
            <span className="text-xs font-normal text-steam-muted">by Salamanca</span>
          </Link>

          <nav className="ml-2 flex items-center gap-1 rounded-2xl border border-white/10 bg-black/25 p-1 text-sm text-steam-muted glow--base">
            <NavItem to="/profile" icon={<FiUser />}>
              Профиль
            </NavItem>
            <NavItem to="/achievements" icon={<FiAward />}>
              Достижения
            </NavItem>
            <NavItem to="/leaderboard" icon={<FiTrendingUp />}>
              Рейтинг
            </NavItem>
            {isAdmin() ? (
              <NavItem to="/admin" icon={<FiShield />}>
                Админ
              </NavItem>
            ) : null}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            {me ? (
              <>
                <span className="hidden text-sm text-steam-muted sm:inline">
                  {me.nickname} {me.role === "ADMIN" ? "(admin)" : ""}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    logout();
                    nav("/login");
                  }}
                >
                  Выйти
                </Button>
              </>
            ) : null}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">{props.children}</main>

      <footer className="mx-auto max-w-6xl px-4 py-10 text-xs text-steam-muted">
        Steam‑style UI, расширяемая архитектура. Backend: Express/Prisma/Postgres.
      </footer>
    </Scene>
  );
}

function NavItem(props: { to: string; icon?: ReactNode; children: ReactNode }) {
  return (
    <NavLink
      to={props.to}
      className={({ isActive }) =>
        clsx(
          "group relative inline-flex items-center gap-2 rounded-xl px-3 py-2",
          "transition-[transform,background-color,color,box-shadow] duration-200 ease-out",
          "hover:bg-white/5 hover:text-steam-text",
          isActive ? "bg-white/5 text-steam-text glow--hover" : "text-steam-muted",
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive ? (
            <motion.span
              layoutId="nav-underline"
              className="absolute inset-x-3 -bottom-[2px] h-[2px] rounded-full bg-steam-accent shadow-[0_0_18px_rgba(102,192,244,0.35)]"
              transition={{ type: "spring", stiffness: 560, damping: 40 }}
            />
          ) : null}
          {props.icon ? <span className="text-base opacity-90">{props.icon}</span> : null}
          <span className="relative z-10">{props.children}</span>
        </>
      )}
    </NavLink>
  );
}

