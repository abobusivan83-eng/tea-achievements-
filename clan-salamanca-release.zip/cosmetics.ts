export type FrameRarity = "common" | "uncommon" | "rare" | "epic" | "legendary" | "secret";
export type FrameShape = "circle" | "square" | "squircle";

export type FrameOverlayId =
  | "none"
  | "metal-steel"
  | "metal-bronze"
  | "metal-gold"
  | "minimal-blue"
  | "minimal-green"
  | "minimal-purple"
  | "carbon-grid"
  | "tech-circuit"
  | "arcane-runes"
  | "royal-crown"
  | "neon-edges"
  | "retro-pixel"
  | "ember-flame"
  | "glacier-crystal"
  | "void-aura"
  | "radioactive"
  | "sigil"
  | "holo-prism";

export type FrameDef = {
  key: string;
  label: string;
  rarity: FrameRarity;
  shape: FrameShape;
  className: string; // visual FX class (glow/shine/particle etc.)
  overlayId: FrameOverlayId; // ornate overlay (SVG)
  animated: boolean;
  adminOnly?: boolean;
  creatorOnly?: boolean;
};

export const frames: FrameDef[] = [
  // Common (10-15): clean, metallic, minimal glow
  { key: "common", label: "Steel Classic", rarity: "common", shape: "circle", className: "frame--common", overlayId: "metal-steel", animated: false },
  { key: "common-sq", label: "Steel Square", rarity: "common", shape: "square", className: "frame--common", overlayId: "metal-steel", animated: false },
  { key: "carbon", label: "Carbon", rarity: "common", shape: "circle", className: "frame--carbon", overlayId: "carbon-grid", animated: false },
  { key: "steam-blueprint", label: "Blueprint", rarity: "uncommon", shape: "squircle", className: "frame--blueprint", overlayId: "tech-circuit", animated: true },
  { key: "common-soft", label: "Soft Glow", rarity: "uncommon", shape: "circle", className: "frame--softglow", overlayId: "minimal-blue", animated: true },
  { key: "common-soft-sq", label: "Soft Glow Square", rarity: "uncommon", shape: "square", className: "frame--softglow", overlayId: "minimal-blue", animated: true },
  { key: "common-min-green", label: "Verdant", rarity: "common", shape: "circle", className: "frame--common", overlayId: "minimal-green", animated: false },
  { key: "common-min-purple", label: "Violet", rarity: "common", shape: "squircle", className: "frame--common", overlayId: "minimal-purple", animated: false },
  { key: "common-bronze", label: "Bronze", rarity: "common", shape: "square", className: "frame--common", overlayId: "metal-bronze", animated: false },
  { key: "common-gold", label: "Gilded", rarity: "uncommon", shape: "circle", className: "frame--rare", overlayId: "metal-gold", animated: false },
  { key: "common-tech", label: "Circuit", rarity: "uncommon", shape: "square", className: "frame--neon", overlayId: "tech-circuit", animated: true },
  { key: "common-retro", label: "Retro Pixel", rarity: "common", shape: "square", className: "frame--blueprint", overlayId: "retro-pixel", animated: true },

  // Rare category: stronger glow + decorative overlays
  { key: "rare", label: "Rare Crest", rarity: "rare", shape: "circle", className: "frame--rare", overlayId: "arcane-runes", animated: false },
  { key: "rare-shine", label: "Rare Shine", rarity: "rare", shape: "circle", className: "frame--rare-shine", overlayId: "arcane-runes", animated: true },
  { key: "rare-squircle", label: "Rare Squircle", rarity: "rare", shape: "squircle", className: "frame--rare", overlayId: "tech-circuit", animated: false },
  { key: "epic", label: "Epic Sigil", rarity: "epic", shape: "circle", className: "frame--epic", overlayId: "sigil", animated: false },
  { key: "epic-shine", label: "Epic Shine", rarity: "epic", shape: "squircle", className: "frame--epic-shine", overlayId: "sigil", animated: true },
  { key: "legendary", label: "Legendary Crown", rarity: "legendary", shape: "circle", className: "frame--legendary", overlayId: "royal-crown", animated: false },
  { key: "legendary-animated", label: "Legendary Prism", rarity: "legendary", shape: "circle", className: "frame--legendary-animated", overlayId: "holo-prism", animated: true },
  { key: "legendary-particles", label: "Legendary Particles", rarity: "legendary", shape: "squircle", className: "frame--legendary-particles", overlayId: "holo-prism", animated: true },
  { key: "discord-neon", label: "Neon", rarity: "epic", shape: "square", className: "frame--neon", overlayId: "neon-edges", animated: true },

  // Rare / Admin (10-15): detailed, always-glow, hover reacts
  { key: "admin-obsidian", label: "Obsidian", rarity: "epic", shape: "circle", className: "frame--obsidian", overlayId: "metal-steel", animated: true, adminOnly: true },
  { key: "admin-ember", label: "Ember", rarity: "legendary", shape: "circle", className: "frame--ember", overlayId: "ember-flame", animated: true, adminOnly: true },
  { key: "admin-aurora", label: "Aurora", rarity: "legendary", shape: "square", className: "frame--aurora", overlayId: "holo-prism", animated: true, adminOnly: true },
  { key: "admin-sigil", label: "Sigil", rarity: "epic", shape: "squircle", className: "frame--sigil", overlayId: "sigil", animated: true, adminOnly: true },
  { key: "admin-holo", label: "Holo", rarity: "rare", shape: "square", className: "frame--holo", overlayId: "holo-prism", animated: true, adminOnly: true },
  { key: "admin-crown", label: "Crown", rarity: "legendary", shape: "circle", className: "frame--crown", overlayId: "royal-crown", animated: true, adminOnly: true },
  { key: "admin-glacier", label: "Glacier", rarity: "epic", shape: "squircle", className: "frame--glacier", overlayId: "glacier-crystal", animated: true, adminOnly: true },

  // Secret (10): creator-only, always-animated, aura/particles
  { key: "admin-void", label: "Void", rarity: "secret", shape: "circle", className: "frame--void", overlayId: "void-aura", animated: true, creatorOnly: true },
  { key: "admin-radioactive", label: "Radioactive", rarity: "secret", shape: "square", className: "frame--radioactive", overlayId: "radioactive", animated: true, creatorOnly: true },
  { key: "secret-neon-core", label: "Neon Core", rarity: "secret", shape: "square", className: "frame--neon", overlayId: "neon-edges", animated: true, creatorOnly: true },
  { key: "secret-ember-gold", label: "Golden Flame", rarity: "secret", shape: "circle", className: "frame--ember", overlayId: "ember-flame", animated: true, creatorOnly: true },
  { key: "secret-holo-royal", label: "Royal Prism", rarity: "secret", shape: "circle", className: "frame--crown", overlayId: "holo-prism", animated: true, creatorOnly: true },
  { key: "secret-sigil-inferno", label: "Inferno Sigil", rarity: "secret", shape: "squircle", className: "frame--legendary-particles", overlayId: "sigil", animated: true, creatorOnly: true },
  { key: "secret-void-runes", label: "Void Runes", rarity: "secret", shape: "squircle", className: "frame--void", overlayId: "arcane-runes", animated: true, creatorOnly: true },
  { key: "secret-glacier", label: "Frozen Relic", rarity: "secret", shape: "square", className: "frame--glacier", overlayId: "glacier-crystal", animated: true, creatorOnly: true },
  { key: "secret-carbon-ops", label: "Black Ops", rarity: "secret", shape: "square", className: "frame--obsidian", overlayId: "carbon-grid", animated: true, creatorOnly: true },
  { key: "secret-retro", label: "Retro Artifact", rarity: "secret", shape: "square", className: "frame--blueprint", overlayId: "retro-pixel", animated: true, creatorOnly: true },
] as const;

export function getFrame(key: string | null | undefined): FrameDef | null {
  if (!key) return null;
  return frames.find((f) => f.key === key) ?? null;
}

export const badgeCatalog = [
  { key: "founder", label: "Основатель" },
  { key: "moderator", label: "Модератор" },
  { key: "veteran", label: "Ветеран" },
  { key: "event-winner", label: "Победитель события" },
] as const;

