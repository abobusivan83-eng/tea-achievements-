## Clan Salamanca — Achievements (Steam-style)

Полноценный стартовый шаблон: **frontend (React + Vite + TS)** + **backend (Node.js + Express + TS + Prisma)** + **PostgreSQL (Docker)**.

### Требования
- **Node.js 20+** (LTS) и npm
- **Docker Desktop** (для PostgreSQL)

### Быстрый запуск (Windows PowerShell)
### One-click запуск (Windows)
- **Рекомендуемый способ**: дважды кликните `run-site.bat` в корне проекта.
  - Откроются 3 окна: Launcher, Backend, Frontend
  - Сайт: `http://localhost:3000`
  - API: `http://localhost:4000/api/health`

Если запускаете из PowerShell (`pwsh`) и хотите отдельные окна с логами, используйте `run-site.ps1`.

### База данных (важно)
- Если установлен **Docker Desktop**, launcher поднимет **PostgreSQL** из `docker-compose.yml`.
- Если Docker **не установлен**, launcher автоматически переключится на **SQLite** (локальный файл `backend/prisma/dev.db`) — чтобы всё запускалось “из коробки” без Docker.

### Ручной запуск (если нужно)
1) Поднять базу:

```bash
docker compose up -d db
```

2) Настроить backend:

```bash
cd backend
copy .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```

3) Запустить frontend:

```bash
cd ..\frontend
copy .env.example .env
npm install
npm run dev
```

Откройте приложение: `http://localhost:3000`

### Учётки
- После `npm run seed` создаётся админ:
  - **email**: `admin@clan.local`
  - **password**: `admin12345`

### Структура
- `backend/`: API, авторизация, роли, достижения, выдача, рейтинг, загрузки аватар/баннеров
- `frontend/`: UI в стилистике Steam, расширенный профиль, достижения с фильтрами, рейтинг, админ-панель

### Расширяемость
- Добавление новых редкостей/типов достижений: `backend/prisma/schema.prisma` + `frontend/src/lib/types.ts`
- Новые события/турниры: отдельные таблицы + страницы, роли и политики уже готовы

