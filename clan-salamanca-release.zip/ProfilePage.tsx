import { useEffect, useMemo, useState } from "react";
import { apiFetch, apiJson, apiUpload } from "../lib/api";
import { useAuth } from "../state/auth";
import { badgeCatalog, frames, getFrame } from "../lib/cosmetics";
import clsx from "clsx";
import { AnimatePresence, motion } from "framer-motion";
import { Button } from "../ui/components/Button";
import { Tabs } from "../ui/components/Tabs";
import { Tooltip } from "../ui/components/Tooltip";
import { FiAward, FiImage, FiSave, FiStar, FiTrendingUp, FiUser } from "react-icons/fi";
import { Reveal } from "../ui/components/Reveal";
import { Skeleton } from "../ui/components/Skeleton";
import { AvatarFrame, canUseFrame } from "../ui/components/AvatarFrame";

type ProfileResp = {
  user: {
    id: string;
    nickname: string;
    role: "USER" | "ADMIN";
    blocked: boolean;
    level?: number;
    xp?: number;
    avatarUrl: string | null;
    bannerUrl: string | null;
    frameKey: string | null;
    badges: string[];
    statusEmoji?: string | null;
    createdAt: string;
  };
  achievements: {
    earned: Array<{
      id: string;
      title: string;
      description: string;
      rarity: string;
      points: number;
      iconUrl: string | null;
      frameKey: string | null;
      awardedAt: string;
    }>;
    locked: Array<{
      id: string;
      title: string;
      description: string;
      rarity: string;
      points: number;
      iconUrl: string | null;
      frameKey: string | null;
    }>;
  };
};

export function ProfilePage() {
  const me = useAuth((s) => s.me);
  const hydrate = useAuth((s) => s.hydrate);
  const [profile, setProfile] = useState<ProfileResp | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [nickname, setNickname] = useState("");
  const [frameKey, setFrameKey] = useState<string | null>(null);
  const [badges, setBadges] = useState<string[]>([]);
  const [burstKey, setBurstKey] = useState(0);
  const [tab, setTab] = useState<"main" | "achievements" | "leaderboard" | "settings">("main");
  const [statusEmoji, setStatusEmoji] = useState<string | null>(null);
  const [lbPos, setLbPos] = useState<{ pos: number | null; totalPoints: number; achievementCount: number } | null>(
    null,
  );

  useEffect(() => {
    let isMounted = true;
    async function run() {
      if (!me) return;
      setLoading(true);
      setError(null);
      try {
        const data = await apiFetch<ProfileResp>(`/api/users/${me.id}`);
        if (!isMounted) return;
        setProfile(data);
        setNickname(data.user.nickname);
        setFrameKey(data.user.frameKey);
        setBadges(data.user.badges);
        setStatusEmoji(data.user.statusEmoji ?? null);
      } catch (e: any) {
        setError(e?.message ?? "Ошибка загрузки профиля");
      } finally {
        setLoading(false);
      }
    }
    run();
    return () => {
      isMounted = false;
    };
  }, [me?.id]);

  useEffect(() => {
    let mounted = true;
    async function run() {
      try {
        const rows = await apiFetch<Array<{ id: string; totalPoints: number; achievementCount: number }>>(
          "/api/leaderboard",
        );
        if (!mounted || !me) return;
        const idx = rows.findIndex((r) => r.id === me.id);
        if (idx >= 0) setLbPos({ pos: idx + 1, totalPoints: rows[idx]!.totalPoints, achievementCount: rows[idx]!.achievementCount });
        else setLbPos({ pos: null, totalPoints: 0, achievementCount: 0 });
      } catch {
        if (mounted) setLbPos(null);
      }
    }
    run();
    return () => {
      mounted = false;
    };
  }, [me?.id]);

  const frameClass = useMemo(() => {
    const f = getFrame(frameKey);
    const fx = f?.className ?? "frame--common";
    const shape = f?.shape === "square" ? "frame--shape-square" : f?.shape === "squircle" ? "frame--shape-squircle" : "";
    return `${fx} ${shape}`.trim();
  }, [frameKey]);

  const canUseAdminFrames = me?.role === "ADMIN";

  if (loading)
    return (
      <div className="grid gap-6">
        <div className="steam-card overflow-hidden">
          <div className="relative h-48 bg-black/40">
            <div className="absolute bottom-4 left-4 flex items-end gap-4">
              <Skeleton className="h-[86px] w-[86px] rounded-full" />
              <div className="grid gap-2">
                <Skeleton className="h-5 w-44 rounded-md" />
                <Skeleton className="h-3 w-56 rounded-md" />
                <div className="mt-2 flex gap-2">
                  <Skeleton className="h-7 w-24 rounded-full" />
                  <Skeleton className="h-7 w-24 rounded-full" />
                </div>
              </div>
            </div>
          </div>
          <div className="p-4">
            <Skeleton className="h-10 w-full rounded-xl" />
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <div className="steam-card p-4">
                <Skeleton className="h-4 w-28 rounded-md" />
                <Skeleton className="mt-3 h-3 w-full rounded-md" />
                <Skeleton className="mt-2 h-3 w-5/6 rounded-md" />
              </div>
              <div className="steam-card p-4">
                <Skeleton className="h-4 w-36 rounded-md" />
                <div className="mt-3 grid gap-2">
                  <Skeleton className="h-12 w-full rounded-xl" />
                  <Skeleton className="h-12 w-full rounded-xl" />
                  <Skeleton className="h-12 w-full rounded-xl" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  if (error) return <div className="steam-card p-4">{error}</div>;
  if (!profile) return null;

  const totalAchievements = profile.achievements.earned.length + profile.achievements.locked.length;
  const progress = totalAchievements ? profile.achievements.earned.length / totalAchievements : 0;

  const level = profile.user.level ?? 1;
  const xp = profile.user.xp ?? 0;
  const xpBase = Math.floor(80 * level + 25 * level * level);
  const xpNext = Math.floor(80 * (level + 1) + 25 * (level + 1) * (level + 1));
  const xpInto = Math.max(0, xp - xpBase);
  const xpForNext = Math.max(1, xpNext - xpBase);
  const xpPct = Math.min(1, xpInto / xpForNext);
  const statusTier = level >= 50 ? "legendary" : level >= 10 ? "rare" : "common";

  return (
    <div className="grid gap-6">
      <Reveal className="steam-card steam-card--hover overflow-hidden">
        <motion.div
          className="relative h-48 bg-black/40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          style={{
            backgroundImage: profile.user.bannerUrl ? `url(${profile.user.bannerUrl})` : undefined,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
          <div className="absolute bottom-4 left-4 flex items-end gap-4">
            <motion.div
              className={clsx("relative")}
              initial={{ scale: 0.9, opacity: 0, y: 8 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 320, damping: 22, delay: 0.05 }}
            >
              <AvatarFrame
                frameKey={frameKey}
                size={80}
                src={profile.user.avatarUrl ?? "https://placehold.co/160x160/png?text=Avatar"}
                alt="avatar"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.08 }}
            >
              <div className="flex items-center gap-2">
                <div className="text-lg font-semibold">{profile.user.nickname}</div>
                {profile.user.statusEmoji ? (
                  <Tooltip content="Status">
                    <span className={clsx("badge text-xs", statusTier === "legendary" ? "status--legendary" : statusTier === "rare" ? "status--rare" : "status--common")}>
                      {profile.user.statusEmoji}
                    </span>
                  </Tooltip>
                ) : null}
              </div>
              <div className="text-xs text-steam-muted">
                ID: <span className="font-mono">{profile.user.id}</span>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {profile.user.badges.slice(0, 6).map((b) => (
                  <motion.span
                    key={b}
                    whileHover={{ y: -1, scale: 1.03 }}
                    className="badge text-xs"
                    title={b}
                  >
                    <FiStar className="opacity-80" />
                    {b}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </div>

          <div className="absolute right-4 top-4 w-52 rounded-xl border border-white/10 bg-black/30 p-3 backdrop-blur">
            <div className="text-xs text-steam-muted">Achievements progress</div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
              <motion.div
                className="h-full rounded-full bg-steam-accent"
                initial={{ width: 0 }}
                animate={{ width: `${Math.round(progress * 100)}%` }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              />
            </div>
            <div className="mt-2 text-xs text-steam-muted">
              {profile.achievements.earned.length} / {totalAchievements} unlocked
            </div>
            <div className="mt-3 border-t border-white/10 pt-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-steam-muted">Level</span>
                <span className="font-semibold">{level}</span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
                <motion.div
                  className="h-full rounded-full bg-steam-green"
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.round(xpPct * 100)}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                />
              </div>
              <div className="mt-2 text-[11px] text-steam-muted">
                XP {xpInto} / {xpForNext}
              </div>
            </div>
          </div>
        </motion.div>

        <div className="p-4">
          <Tabs
            items={[
              { key: "main", label: "Основное", icon: <FiUser /> },
              { key: "achievements", label: "Достижения", icon: <FiAward /> },
              { key: "leaderboard", label: "Рейтинг", icon: <FiTrendingUp /> },
              { key: "settings", label: "Настройки", icon: <FiSave /> },
            ]}
            value={tab}
            onChange={setTab}
          />

          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
            className="mt-4"
          >
            {tab === "main" ? (
              <div className="grid gap-4 md:grid-cols-2">
                <div className="steam-card p-4">
                  <div className="text-sm font-semibold">Основное</div>
                  <div className="mt-2 text-sm text-steam-muted">
                    Профиль в стиле Steam с премиальными настройками, анимациями и системой уровней.
                  </div>
                  <div className="mt-4 grid gap-2 text-sm">
                    <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 p-3">
                      <span className="text-steam-muted">Status</span>
                      <span
                        className={clsx(
                          "badge text-xs",
                          statusTier === "legendary" ? "status--legendary" : statusTier === "rare" ? "status--rare" : "status--common",
                        )}
                      >
                        {profile.user.statusEmoji ?? "—"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 p-3">
                      <span className="text-steam-muted">Leaderboard position</span>
                      <span className="font-semibold">{lbPos?.pos ? `#${lbPos.pos}` : "—"}</span>
                    </div>
                  </div>
                </div>

                <div className="steam-card p-4">
                  <div className="text-sm font-semibold">Быстрый прогресс</div>
                  <div className="mt-3 grid gap-2">
                    {profile.achievements.earned.slice(0, 4).map((a) => (
                      <AchievementRow key={a.id} title={a.title} desc={a.description} iconUrl={a.iconUrl} locked={false} />
                    ))}
                    {profile.achievements.earned.length === 0 ? (
                      <div className="text-sm text-steam-muted">Пока нет открытых достижений.</div>
                    ) : null}
                  </div>
                </div>
              </div>
            ) : null}

            {tab === "achievements" ? (
              <div className="grid gap-4 md:grid-cols-2">
                <div className="steam-card p-4">
                  <div className="text-sm font-semibold">Открытые</div>
                  <div className="mt-3 grid gap-2">
                    {profile.achievements.earned.map((a) => (
                      <AchievementRow key={a.id} title={a.title} desc={a.description} iconUrl={a.iconUrl} locked={false} />
                    ))}
                    {profile.achievements.earned.length === 0 ? (
                      <div className="text-sm text-steam-muted">Пока нет открытых достижений.</div>
                    ) : null}
                  </div>
                </div>
                <div className="steam-card p-4">
                  <div className="text-sm font-semibold">Закрытые</div>
                  <div className="mt-3 grid gap-2">
                    {profile.achievements.locked.map((a) => (
                      <AchievementRow key={a.id} title={a.title} desc={a.description} iconUrl={a.iconUrl} locked={true} />
                    ))}
                    {profile.achievements.locked.length === 0 ? (
                      <div className="text-sm text-steam-muted">Все достижения открыты.</div>
                    ) : null}
                  </div>
                </div>
              </div>
            ) : null}

            {tab === "leaderboard" ? (
              <div className="grid gap-4 md:grid-cols-2">
                <div className="steam-card p-4">
                  <div className="text-sm font-semibold">Рейтинг</div>
                  <div className="mt-2 text-sm text-steam-muted">Позиция и очки обновляются динамически.</div>
                  <div className="mt-4 grid gap-2 text-sm">
                    <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 p-3">
                      <span className="text-steam-muted">Position</span>
                      <span className="font-semibold">{lbPos?.pos ? `#${lbPos.pos}` : "—"}</span>
                    </div>
                    <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 p-3">
                      <span className="text-steam-muted">Points</span>
                      <span className="font-semibold text-steam-accent">{lbPos?.totalPoints ?? 0}</span>
                    </div>
                    <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 p-3">
                      <span className="text-steam-muted">Achievements</span>
                      <span className="font-semibold">{lbPos?.achievementCount ?? 0}</span>
                    </div>
                  </div>
                </div>

                <div className="steam-card p-4">
                  <div className="text-sm font-semibold">Совет</div>
                  <div className="mt-2 text-sm text-steam-muted">
                    Награды и редкость достижений влияют на очки. Легендарные награды дают больше XP и повышают уровень.
                  </div>
                </div>
              </div>
            ) : null}

            {tab === "settings" ? (
              <div className="grid gap-4 md:grid-cols-2">
                <section className="grid gap-3">
                  <div className="text-sm font-semibold">Настройки профиля</div>

            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Никнейм</span>
              <input
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
              />
            </label>

            <div className="grid gap-2 text-sm">
              <div className="text-steam-muted">Статус-эмодзи</div>
              <StatusEmojiPicker value={statusEmoji} onChange={setStatusEmoji} />
            </div>

            <div className="grid gap-2 text-sm">
              <div className="text-steam-muted">Рамка аватарки</div>
              <div className="flex flex-wrap gap-2">
                {frames.map((f) => (
                  <motion.button
                    key={f.key}
                    type="button"
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.98 }}
                    className={clsx(
                      "flex items-center gap-2 rounded-lg border px-3 py-2 text-xs",
                      frameKey === f.key
                        ? "border-steam-accent bg-white/10"
                        : "border-white/10 bg-white/5 hover:bg-white/10",
                      !canUseFrame({ frameKey: f.key, meId: me?.id, isAdmin: canUseAdminFrames }) &&
                        "cursor-not-allowed opacity-40 hover:bg-white/5",
                    )}
                    onClick={() => {
                      if (!canUseFrame({ frameKey: f.key, meId: me?.id, isAdmin: canUseAdminFrames })) return;
                      setFrameKey(f.key);
                    }}
                    title={
                      f.creatorOnly
                        ? "Только для создателя"
                        : f.adminOnly && !canUseAdminFrames
                          ? "Только для админов"
                          : f.animated
                            ? "Анимированная"
                            : "Статичная"
                    }
                  >
                    <AvatarFrame
                      frameKey={f.key}
                      size={26}
                      src={profile.user.avatarUrl ?? "https://placehold.co/64x64/png?text=A"}
                    />
                    <span className="truncate">{f.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>

            <div className="grid gap-2 text-sm">
              <div className="text-steam-muted">Статусные значки</div>
              <div className="flex flex-wrap gap-2">
                {badgeCatalog.map((b) => {
                  const active = badges.includes(b.key);
                  return (
                    <button
                      key={b.key}
                      type="button"
                      className={clsx(
                        "badge text-xs",
                        active ? "border-steam-accent/40 bg-steam-accent/10" : "hover:bg-white/10",
                      )}
                      onClick={() => {
                        setBadges((prev) => (prev.includes(b.key) ? prev.filter((x) => x !== b.key) : [...prev, b.key]));
                      }}
                    >
                      <span className={clsx("h-2 w-2 rounded-full", active ? "bg-steam-green" : "bg-white/20")} />
                      {b.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2">
              <UploadImageButton
                label="Загрузить аватар"
                icon={<FiImage />}
                onPick={async (file) => {
                  await apiUpload("/api/users/me/avatar", file);
                  await hydrate();
                  const data = await apiFetch<ProfileResp>(`/api/users/${profile.user.id}`);
                  setProfile(data);
                }}
              />
              <UploadImageButton
                label="Загрузить баннер"
                icon={<FiImage />}
                onPick={async (file) => {
                  await apiUpload("/api/users/me/banner", file);
                  await hydrate();
                  const data = await apiFetch<ProfileResp>(`/api/users/${profile.user.id}`);
                  setProfile(data);
                }}
              />

              <Button
                loading={saving}
                leftIcon={<FiSave />}
                onClick={async () => {
                  setSaving(true);
                  setError(null);
                  try {
                    await apiJson("/api/users/me", { nickname, frameKey, badges, statusEmoji }, "PATCH");
                    const data = await apiFetch<ProfileResp>(`/api/users/${profile.user.id}`);
                    setProfile(data);
                    await hydrate();
                    setBurstKey((x) => x + 1);
                  } catch (e: any) {
                    setError(e?.message ?? "Не удалось сохранить");
                  } finally {
                    setSaving(false);
                  }
                }}
              >
                Сохранить
              </Button>
            </div>
                </section>

                <section className="grid gap-3">
                  <div className="text-sm font-semibold">Preview</div>
                  <div className="steam-card p-4">
                    <div className="text-xs text-steam-muted">How your profile looks</div>
                    <div className="mt-3 flex items-center gap-3">
                      <AvatarFrame frameKey={frameKey} size={48} src={profile.user.avatarUrl ?? "https://placehold.co/96x96/png?text=Avatar"} />
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold">
                          {nickname} {statusEmoji ? <span className="ml-2">{statusEmoji}</span> : null}
                        </div>
                        <div className="text-xs text-steam-muted">Frame: {frameKey ?? "default"}</div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            ) : null}
          </motion.div>
        </div>
      </Reveal>

      <ConfettiBurst burstKey={burstKey} />

      <div className="grid gap-3 md:grid-cols-2">
        <Reveal className="steam-card p-4">
          <div className="text-sm font-semibold">Коротко о системе</div>
          <div className="mt-2 text-sm text-steam-muted">
            Достижения бывают публичные и приватные. Приватные видны только пользователям, которым админ выдал доступ или
            награду. Очки влияют на рейтинг.
          </div>
        </Reveal>

        <Reveal className="steam-card p-4" delay={0.04}>
          <div className="text-sm font-semibold">Анимации</div>
          <div className="mt-2 text-sm text-steam-muted">
            Легендарные рамки могут быть анимированными. Баннер, значки и рамки можно расширять каталогом в коде без
            изменения схемы БД.
          </div>
        </Reveal>
      </div>
    </div>
  );
}

function AchievementRow(props: { title: string; desc: string; iconUrl: string | null; locked: boolean }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      className={clsx(
        "flex items-center gap-3 rounded-xl border border-white/10 bg-black/20 p-3",
        props.locked ? "opacity-60" : "opacity-100",
      )}
    >
      <div className="h-10 w-10 overflow-hidden rounded-lg border border-white/10 bg-black/30">
        {props.iconUrl ? <img className="h-full w-full object-cover" src={props.iconUrl} alt="" loading="lazy" decoding="async" /> : null}
      </div>
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold">{props.title}</div>
        <div className="truncate text-xs text-steam-muted">{props.desc}</div>
      </div>
      {props.locked ? <div className="ml-auto text-xs text-steam-muted">Закрыто</div> : <div className="ml-auto text-xs text-steam-green">Открыто</div>}
    </motion.div>
  );
}

function UploadImageButton(props: { label: string; icon?: React.ReactNode; onPick: (file: File) => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  return (
    <label
      className={clsx(
        "cursor-pointer rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm hover:bg-white/10",
        busy && "opacity-60",
      )}
    >
      <input
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          setBusy(true);
          try {
            await props.onPick(file);
          } finally {
            setBusy(false);
            e.currentTarget.value = "";
          }
        }}
        disabled={busy}
      />
      <span className="inline-flex items-center gap-2">
        {props.icon ? <span className="text-base opacity-80">{props.icon}</span> : null}
        {busy ? "Загрузка…" : props.label}
      </span>
    </label>
  );
}

function StatusEmojiPicker(props: { value: string | null; onChange: (v: string | null) => void }) {
  const emojis = ["😀", "😎", "🥷", "🔥", "✨", "💎", "🏆", "⚡", "🌙", "🌟", "🎯", "🧠", "🛡️", "💀", "🦊", "🐍"];
  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        className={clsx(
          "badge text-xs",
          !props.value ? "border-steam-accent/40 bg-steam-accent/10" : "hover:bg-white/10",
        )}
        onClick={() => props.onChange(null)}
        title="No status"
      >
        —
      </button>
      {emojis.map((e) => {
        const active = props.value === e;
        return (
          <motion.button
            key={e}
            type="button"
            whileHover={{ y: -1, scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            className={clsx("badge text-xs", active ? "border-steam-accent/40 bg-steam-accent/10" : "hover:bg-white/10")}
            onClick={() => props.onChange(e)}
          >
            {e}
          </motion.button>
        );
      })}
    </div>
  );
}

function ConfettiBurst(props: { burstKey: number }) {
  return (
    <AnimatePresence>
      {props.burstKey > 0 ? (
        <motion.div
          key={props.burstKey}
          className="pointer-events-none fixed inset-0 z-40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {Array.from({ length: 18 }).map((_, i) => (
            <motion.span
              key={i}
              className="absolute left-1/2 top-20 h-2 w-2 rounded-sm bg-steam-accent"
              initial={{ x: 0, y: 0, rotate: 0, opacity: 1, scale: 1 }}
              animate={{
                x: (Math.random() * 2 - 1) * 240,
                y: Math.random() * 220 + 60,
                rotate: Math.random() * 540,
                opacity: 0,
                scale: 0.6,
              }}
              transition={{ duration: 0.9 + Math.random() * 0.35, ease: "easeOut" }}
              style={{
                background:
                  i % 3 === 0 ? "rgba(102,192,244,0.95)" : i % 3 === 1 ? "rgba(92,219,149,0.9)" : "rgba(255,190,70,0.9)",
              }}
            />
          ))}
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

