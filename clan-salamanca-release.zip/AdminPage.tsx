import { useEffect, useMemo, useState } from "react";
import { apiDelete, apiFetch, apiJson, apiUpload } from "../lib/api";
import type { AdminAchievement, AdminUserRow, Rarity } from "../lib/types";
import { Button } from "../ui/components/Button";
import { Modal } from "../ui/components/Modal";
import { motion } from "framer-motion";
import { FiAward, FiEdit2, FiSearch, FiTrash2, FiUser } from "react-icons/fi";
import { useToasts } from "../state/toasts";
import { ConfirmModal } from "../ui/components/ConfirmModal";
import { Reveal } from "../ui/components/Reveal";
import { Skeleton } from "../ui/components/Skeleton";
import { rarityGlowClass } from "../ui/rarityStyles";
import clsx from "clsx";

type CreatedAchievement = {
  id: string;
  title: string;
  rarity: Rarity;
  points: number;
  isPublic: boolean;
};

export function AdminPage() {
  const toast = useToasts((s) => s.push);
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [achievements, setAchievements] = useState<AdminAchievement[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [tab, setTab] = useState<"achievements" | "users">("achievements");
  const [userQuery, setUserQuery] = useState("");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [rarity, setRarity] = useState<Rarity>("COMMON");
  const [isPublic, setIsPublic] = useState(true);
  const [frameKey, setFrameKey] = useState<string>("");
  const [grantIds, setGrantIds] = useState("");
  const [created, setCreated] = useState<CreatedAchievement | null>(null);
  const [iconFile, setIconFile] = useState<File | null>(null);
  const [awardUserId, setAwardUserId] = useState("");

  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<AdminAchievement | null>(null);

  const [awardOpen, setAwardOpen] = useState(false);
  const [awardAchId, setAwardAchId] = useState<string>("");
  const [awardUserId2, setAwardUserId2] = useState<string>("");

  const [userDetailsOpen, setUserDetailsOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AdminUserRow | null>(null);
  const [notesDraft, setNotesDraft] = useState("");
  const [tagsDraft, setTagsDraft] = useState("");
  const [levelDraft, setLevelDraft] = useState<number>(1);
  const [xpDraft, setXpDraft] = useState<number>(0);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmTarget, setConfirmTarget] = useState<AdminAchievement | null>(null);

  async function refreshUsers() {
    setLoadingUsers(true);
    try {
      const data = await apiFetch<AdminUserRow[]>("/api/admin/users");
      setUsers(data);
    } finally {
      setLoadingUsers(false);
    }
  }

  async function refreshAchievements() {
    const data = await apiFetch<AdminAchievement[]>("/api/admin/achievements");
    setAchievements(data);
  }

  useEffect(() => {
    Promise.all([refreshUsers(), refreshAchievements()]).catch((e: any) => setError(e?.message ?? "Ошибка загрузки"));
  }, []);

  const userIdsHint = useMemo(() => users.slice(0, 6).map((u) => u.id), [users]);
  const filteredUsers = useMemo(() => {
    const q = userQuery.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) =>
        u.nickname.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.id.toLowerCase().includes(q) ||
        (u.adminTags ?? []).some((t) => t.toLowerCase().includes(q)),
    );
  }, [users, userQuery]);

  return (
    <div className="grid gap-6">
      <Reveal className="steam-card steam-card--hover p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="mr-auto">
            <div className="text-lg font-semibold">Админ-панель</div>
            <div className="text-sm text-steam-muted">Достижения, выдача/отзыв, пользователи, заметки и метки.</div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={tab === "achievements" ? "primary" : "ghost"}
              size="sm"
              leftIcon={<FiAward />}
              onClick={() => setTab("achievements")}
            >
              Achievements
            </Button>
            <Button
              variant={tab === "users" ? "primary" : "ghost"}
              size="sm"
              leftIcon={<FiUser />}
              onClick={() => setTab("users")}
            >
              Users
            </Button>
          </div>
        </div>
      </Reveal>

      {error ? <div className="steam-card p-4">{error}</div> : null}

      {tab === "achievements" ? (
        <div className="grid gap-6 lg:grid-cols-2">
          <section className="steam-card steam-card--hover p-4">
            <div className="text-sm font-semibold">Create achievement</div>
            <div className="mt-3 grid gap-3">
            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Название</span>
              <input
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </label>

            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Описание</span>
              <textarea
                className="min-h-20 rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </label>

            <div className="flex flex-wrap items-center gap-2">
              <select
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none"
                value={rarity}
                onChange={(e) => setRarity(e.target.value as Rarity)}
              >
                <option value="COMMON">COMMON</option>
                <option value="RARE">RARE</option>
                <option value="EPIC">EPIC</option>
                <option value="LEGENDARY">LEGENDARY</option>
              </select>

              <label className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm">
                <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} />
                <span>Публичное</span>
              </label>

              <input
                className="flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-steam-accent"
                placeholder="frameKey (опц.) например legendary-animated"
                value={frameKey}
                onChange={(e) => setFrameKey(e.target.value)}
              />
            </div>

            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Приватный доступ (user IDs, через запятую)</span>
              <input
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                placeholder={userIdsHint.length ? userIdsHint.join(", ") : "userId1, userId2"}
                value={grantIds}
                onChange={(e) => setGrantIds(e.target.value)}
              />
            </label>

            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Иконка (png/jpg/webp/gif)</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setIconFile(e.target.files?.[0] ?? null)}
              />
            </label>

            <button
              className="hidden"
            />
            <Button
              leftIcon={<FiAward />}
              onClick={async () => {
                setError(null);
                const grantUserIds = grantIds
                  .split(",")
                  .map((x) => x.trim())
                  .filter(Boolean);
                try {
                  const created = await apiJson<CreatedAchievement>("/api/admin/achievements", {
                    title,
                    description,
                    rarity,
                    isPublic,
                    frameKey: frameKey.trim() ? frameKey.trim() : null,
                    grantUserIds: grantUserIds.length ? grantUserIds : undefined,
                  });
                  setCreated(created);
                  if (iconFile) await apiUpload(`/api/admin/achievements/${created.id}/icon`, iconFile);
                  await refreshAchievements();
                  toast({ kind: "success", title: "Achievement created" });
                } catch (e: any) {
                  setError(e?.message ?? "Ошибка создания");
                  toast({ kind: "error", title: "Create failed", message: e?.message ?? "Error" });
                }
              }}
            >
              Create
            </Button>

            {created ? (
              <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-sm">
                <div className="font-semibold">Создано</div>
                <div className="mt-1 text-xs text-steam-muted">
                  ID: <span className="font-mono">{created.id}</span>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <input
                    className="flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-steam-accent"
                    placeholder="User ID для выдачи"
                    value={awardUserId}
                    onChange={(e) => setAwardUserId(e.target.value)}
                  />
                  <Button
                    variant="ghost"
                    onClick={async () => {
                      try {
                        await apiJson(`/api/admin/achievements/${created.id}/award`, { userId: awardUserId });
                      } catch (e: any) {
                        setError(e?.message ?? "Ошибка выдачи");
                      }
                    }}
                  >
                    Award
                  </Button>
                </div>
              </div>
            ) : null}
            </div>
          </section>

          <section className="steam-card steam-card--hover p-4">
            <div className="flex items-center gap-2">
              <div className="text-sm font-semibold">All achievements</div>
              <div className="ml-auto flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  leftIcon={<FiAward />}
                  onClick={() => {
                    setAwardAchId(achievements[0]?.id ?? "");
                    setAwardUserId2(users[0]?.id ?? "");
                    setAwardOpen(true);
                  }}
                >
                  Award existing
                </Button>
                <Button variant="ghost" size="sm" onClick={() => refreshAchievements().catch((e: any) => setError(e?.message ?? "Load error"))}>
                  Refresh
                </Button>
              </div>
            </div>

            <div className="mt-3 grid gap-2">
              {achievements.slice(0, 80).map((a) => (
                <motion.div
                  key={a.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={clsx("steam-card steam-card--hover p-3", rarityGlowClass(a.rarity, true))}
                >
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 overflow-hidden rounded-lg border border-white/10 bg-black/30">
                      {a.iconUrl ? (
                        <img className="h-full w-full object-cover" src={a.iconUrl} alt="" loading="lazy" decoding="async" />
                      ) : null}
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold">{a.title}</div>
                      <div className="truncate text-xs text-steam-muted">{a.description}</div>
                      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                        <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1">{a.rarity}</span>
                        <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1">{a.points} pts</span>
                        <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1">{a.isPublic ? "public" : "private"}</span>
                      </div>
                    </div>
                    <div className="ml-auto flex flex-wrap items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        leftIcon={<FiEdit2 />}
                        onClick={() => {
                          setEditing(a);
                          setEditOpen(true);
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="danger"
                        size="sm"
                        leftIcon={<FiTrash2 />}
                        onClick={async () => {
                          setConfirmTarget(a);
                          setConfirmOpen(true);
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        </div>
      ) : (
        <section className="steam-card steam-card--hover p-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="text-sm font-semibold">Users</div>
            <div className="ml-auto flex items-center gap-2">
              <div className="relative">
                <FiSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-steam-muted" />
                <input
                  className="w-72 rounded-lg border border-white/10 bg-black/30 py-2 pl-9 pr-3 text-sm outline-none focus:border-steam-accent"
                  placeholder="Search users…"
                  value={userQuery}
                  onChange={(e) => setUserQuery(e.target.value)}
                />
              </div>
              <Button variant="ghost" size="sm" onClick={() => refreshUsers().catch((e: any) => setError(e?.message ?? "Load error"))}>
                Refresh
              </Button>
            </div>
          </div>

          {loadingUsers ? (
            <div className="mt-3 grid gap-2">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="rounded-xl border border-white/10 bg-black/20 p-3">
                  <div className="grid gap-2">
                    <Skeleton className="h-4 w-48 rounded-md" />
                    <Skeleton className="h-3 w-64 rounded-md" />
                    <Skeleton className="h-3 w-52 rounded-md" />
                  </div>
                </div>
              ))}
            </div>
          ) : null}

          <div className="mt-3 grid gap-2">
            {filteredUsers.map((u) => (
              <motion.div key={u.id} whileHover={{ y: -1 }} className="rounded-xl border border-white/10 bg-black/20 p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    className="min-w-0 text-left"
                    onClick={() => {
                      setSelectedUser(u);
                      setNotesDraft(u.adminNotes ?? "");
                      setTagsDraft((u.adminTags ?? []).join(", "));
                      setLevelDraft((u as any).level ?? 1);
                      setXpDraft((u as any).xp ?? 0);
                      setUserDetailsOpen(true);
                    }}
                  >
                    <div className="truncate text-sm font-semibold">
                      {u.nickname}{" "}
                      <span className="text-xs font-normal text-steam-muted">
                        ({u.role}) {u.blocked ? "— blocked" : ""}
                      </span>
                    </div>
                    <div className="truncate font-mono text-[11px] text-steam-muted">{u.id}</div>
                    <div className="text-xs text-steam-muted">{u.email}</div>
                  </button>

                  <div className="ml-auto flex flex-wrap items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={async () => {
                        const nextRole = u.role === "ADMIN" ? "USER" : "ADMIN";
                        await apiJson(`/api/admin/users/${u.id}`, { role: nextRole }, "PATCH");
                        await refreshUsers();
                      }}
                    >
                      {u.role === "ADMIN" ? "Remove admin" : "Make admin"}
                    </Button>
                    <Button
                      variant={u.blocked ? "ghost" : "danger"}
                      size="sm"
                      onClick={async () => {
                        await apiJson(`/api/admin/users/${u.id}`, { blocked: !u.blocked }, "PATCH");
                        await refreshUsers();
                      }}
                    >
                      {u.blocked ? "Unblock" : "Block"}
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      <Modal
        open={editOpen}
        title={editing ? `Edit: ${editing.title}` : "Edit achievement"}
        onClose={() => setEditOpen(false)}
      >
        {editing ? (
          <div className="grid gap-3">
            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Title</span>
              <input
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={editing.title}
                onChange={(e) => setEditing({ ...editing, title: e.target.value })}
              />
            </label>
            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Description</span>
              <textarea
                className="min-h-20 rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              />
            </label>
            <div className="flex flex-wrap gap-2">
              <select
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none"
                value={editing.rarity}
                onChange={(e) => setEditing({ ...editing, rarity: e.target.value as Rarity })}
              >
                <option value="COMMON">COMMON</option>
                <option value="RARE">RARE</option>
                <option value="EPIC">EPIC</option>
                <option value="LEGENDARY">LEGENDARY</option>
              </select>
              <input
                className="w-32 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-steam-accent"
                value={editing.points}
                onChange={(e) => setEditing({ ...editing, points: Number(e.target.value) || 0 })}
              />
              <input
                className="flex-1 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-steam-accent"
                placeholder="frameKey"
                value={editing.frameKey ?? ""}
                onChange={(e) => setEditing({ ...editing, frameKey: e.target.value || null })}
              />
              <label className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={editing.isPublic}
                  onChange={(e) => setEditing({ ...editing, isPublic: e.target.checked })}
                />
                <span>Public</span>
              </label>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" onClick={() => setEditOpen(false)}>
                Cancel
              </Button>
              <Button
                leftIcon={<FiEdit2 />}
                onClick={async () => {
                  try {
                    const updated = await apiJson<AdminAchievement>(`/api/admin/achievements/${editing.id}`, {
                      title: editing.title,
                      description: editing.description,
                      rarity: editing.rarity,
                      points: editing.points,
                      frameKey: editing.frameKey,
                      isPublic: editing.isPublic,
                    }, "PATCH");
                    setEditing(updated);
                    await refreshAchievements();
                    setEditOpen(false);
                  } catch (e: any) {
                    setError(e?.message ?? "Update failed");
                  }
                }}
              >
                Save
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>

      <Modal
        open={userDetailsOpen}
        title={selectedUser ? `User: ${selectedUser.nickname}` : "User"}
        onClose={() => setUserDetailsOpen(false)}
      >
        {selectedUser ? (
          <div className="grid gap-3">
            <div className="text-xs text-steam-muted">
              ID: <span className="font-mono">{selectedUser.id}</span>
            </div>

            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Admin notes</span>
              <textarea
                className="min-h-24 rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={notesDraft}
                onChange={(e) => setNotesDraft(e.target.value)}
              />
            </label>

            <label className="grid gap-1 text-sm">
              <span className="text-steam-muted">Admin tags (comma-separated)</span>
              <input
                className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 outline-none focus:border-steam-accent"
                value={tagsDraft}
                onChange={(e) => setTagsDraft(e.target.value)}
              />
            </label>

            <div className="grid gap-2 rounded-xl border border-white/10 bg-black/20 p-3">
              <div className="text-sm font-semibold">Levels</div>
              <div className="grid gap-2 md:grid-cols-2">
                <label className="grid gap-1 text-sm">
                  <span className="text-steam-muted">Level</span>
                  <select
                    className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none"
                    value={levelDraft}
                    onChange={(e) => setLevelDraft(Number(e.target.value))}
                  >
                    {Array.from({ length: 50 }).map((_, i) => (
                      <option key={i + 1} value={i + 1}>
                        {i + 1}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="grid gap-1 text-sm">
                  <span className="text-steam-muted">XP</span>
                  <input
                    className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-steam-accent"
                    value={xpDraft}
                    onChange={(e) => setXpDraft(Number(e.target.value) || 0)}
                  />
                </label>
              </div>
              <div className="text-xs text-steam-muted">
                Tip: set XP to adjust progress. Award/revoke achievements also changes XP automatically.
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-2">
              <Button variant="ghost" onClick={() => setUserDetailsOpen(false)}>
                Close
              </Button>
              <Button
                leftIcon={<FiUser />}
                onClick={async () => {
                  const tags = tagsDraft
                    .split(",")
                    .map((x) => x.trim())
                    .filter(Boolean);
                  try {
                    const updated = await apiJson<AdminUserRow>(
                      `/api/admin/users/${selectedUser.id}`,
                      { adminNotes: notesDraft || null, adminTags: tags, level: levelDraft, xp: xpDraft },
                      "PATCH",
                    );
                    setSelectedUser(updated);
                    await refreshUsers();
                    setUserDetailsOpen(false);
                    toast({ kind: "success", title: "User updated" });
                  } catch (e: any) {
                    setError(e?.message ?? "Update failed");
                    toast({ kind: "error", title: "Update failed", message: e?.message ?? "Error" });
                  }
                }}
              >
                Save notes
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>

      <Modal open={awardOpen} title="Award existing achievement" onClose={() => setAwardOpen(false)}>
        <div className="grid gap-3">
          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">Achievement</span>
            <select
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none"
              value={awardAchId}
              onChange={(e) => setAwardAchId(e.target.value)}
            >
              {achievements.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.title} ({a.rarity})
                </option>
              ))}
            </select>
          </label>

          <label className="grid gap-1 text-sm">
            <span className="text-steam-muted">User</span>
            <select
              className="rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none"
              value={awardUserId2}
              onChange={(e) => setAwardUserId2(e.target.value)}
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.nickname} ({u.email})
                </option>
              ))}
            </select>
          </label>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={() => setAwardOpen(false)}>
              Cancel
            </Button>
            <Button
              leftIcon={<FiAward />}
              onClick={async () => {
                try {
                  await apiJson(`/api/admin/achievements/${awardAchId}/award`, { userId: awardUserId2 });
                  toast({ kind: "success", title: "Awarded" });
                  setAwardOpen(false);
                } catch (e: any) {
                  setError(e?.message ?? "Award failed");
                  toast({ kind: "error", title: "Award failed", message: e?.message ?? "Error" });
                }
              }}
            >
              Award
            </Button>
            <Button
              variant="danger"
              leftIcon={<FiTrash2 />}
              onClick={async () => {
                try {
                  await apiJson(`/api/admin/achievements/${awardAchId}/revoke`, { userId: awardUserId2 });
                  toast({ kind: "info", title: "Revoked" });
                  setAwardOpen(false);
                } catch (e: any) {
                  setError(e?.message ?? "Revoke failed");
                  toast({ kind: "error", title: "Revoke failed", message: e?.message ?? "Error" });
                }
              }}
            >
              Revoke
            </Button>
          </div>
        </div>
      </Modal>

      <ConfirmModal
        open={confirmOpen}
        title="Delete achievement"
        message={
          confirmTarget
            ? `This will permanently delete "${confirmTarget.title}" and all related awards/access. Continue?`
            : "Delete this achievement?"
        }
        danger
        confirmText="Delete"
        onCancel={() => {
          setConfirmOpen(false);
          setConfirmTarget(null);
        }}
        onConfirm={async () => {
          if (!confirmTarget) return;
          try {
            await apiDelete(`/api/admin/achievements/${confirmTarget.id}`);
            toast({ kind: "success", title: "Achievement deleted" });
            await refreshAchievements();
          } catch (e: any) {
            setError(e?.message ?? "Delete failed");
            toast({ kind: "error", title: "Delete failed", message: e?.message ?? "Error" });
          } finally {
            setConfirmOpen(false);
            setConfirmTarget(null);
          }
        }}
      />
    </div>
  );
}

