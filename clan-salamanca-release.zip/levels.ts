export function xpForLevel(level: number): number {
  // Steam-like curve: grows faster over time, but early levels are quick.
  const l = Math.max(1, Math.floor(level));
  return Math.floor(80 * l + 25 * l * l);
}

export function levelFromXp(xp: number): { level: number; xpIntoLevel: number; xpForNext: number } {
  const safeXp = Math.max(0, Math.floor(xp));
  let level = 1;
  while (safeXp >= xpForLevel(level + 1) && level < 500) level++;
  const xpIntoLevel = safeXp - xpForLevel(level);
  const xpForNext = xpForLevel(level + 1) - xpForLevel(level);
  return { level, xpIntoLevel: Math.max(0, xpIntoLevel), xpForNext: Math.max(1, xpForNext) };
}

