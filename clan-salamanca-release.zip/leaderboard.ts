import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";
import { ok } from "../lib/http.js";
import { toPublicFileUrl } from "../lib/publicUrl.js";
import { levelFromXp } from "../lib/levels.js";

export const leaderboardRouter = Router();

leaderboardRouter.get("/", requireAuth, async (_req, res) => {
  // Aggregate points per user
  const rows = await prisma.user.findMany({
    select: {
      id: true,
      nickname: true,
      avatarPath: true,
      frameKey: true,
      level: true,
      xp: true,
      achievements: {
        select: { achievement: { select: { points: true } } },
      },
    },
  });

  const mapped = rows
    .map((u) => {
      const points = u.achievements.reduce((sum, x) => sum + x.achievement.points, 0);
      const count = u.achievements.length;
      return {
        id: u.id,
        nickname: u.nickname,
        avatarUrl: toPublicFileUrl(u.avatarPath),
        frameKey: u.frameKey,
        totalPoints: points,
        achievementCount: count,
        level: u.level,
        xp: u.xp,
        xpIntoLevel: levelFromXp(u.xp).xpIntoLevel,
        xpForNext: levelFromXp(u.xp).xpForNext,
      };
    })
    .sort((a, b) => b.totalPoints - a.totalPoints);

  return ok(res, mapped.slice(0, 100));
});

