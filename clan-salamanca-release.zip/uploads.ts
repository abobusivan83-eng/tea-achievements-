import multer from "multer";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { env } from "../lib/env.js";

function ensureDir(p: string) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

const uploadRoot = path.resolve(process.cwd(), env.UPLOAD_DIR);
ensureDir(uploadRoot);

const storage = multer.diskStorage({
  destination(req, _file, cb) {
    const dest = path.join(uploadRoot, "user");
    ensureDir(dest);
    cb(null, dest);
  },
  filename(_req, file, cb) {
    const ext = path.extname(file.originalname || "").slice(0, 10) || ".bin";
    const safeExt = ext.match(/^\.[a-z0-9]+$/i) ? ext : ".bin";
    cb(null, `${crypto.randomUUID()}${safeExt}`);
  },
});

export const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter(_req, file, cb) {
    if (!file.mimetype.startsWith("image/")) return cb(new Error("Images only"));
    cb(null, true);
  },
});

